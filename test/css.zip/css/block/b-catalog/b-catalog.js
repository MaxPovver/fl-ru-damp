window.addEvent('domready', 
function() {
	/*$$('.b-catalog__item').getElement('.b-catalog__link').addEvent('click',function(){
		this.getNext('.b-catalog__inner-list').toggleClass('b-catalog__inner-list_hide');
		return false;
		})*/

})







